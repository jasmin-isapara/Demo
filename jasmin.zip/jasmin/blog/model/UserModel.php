<?php

include "BaseModel.php";
include 'AuthenticationModel.php';

class UserModel extends BaseModel
{
  public $baseModel;
  public $authenticationModel;
  public $table = "users";
  public $table1 = "detail_blog";

  public function __construct()
  {
    $this->baseModel = new BaseModel();
    $this->authenticationModel = new AuthenticationModel();
    // return $this->authenticationModel;
  }

  public function create($request)
  {
    $fields = 'first_name, last_name, email, mobile_no, password, image';
    $values = "'" . implode("','", array_values($request)) . "'";
    $img = $_FILES['image']['name'];
    $values .= ",'" . $img . "'";
    $img_tmp = $_FILES['image'];
    $img_tmp = $_FILES['image']['tmp_name'];
    move_uploaded_file($img_tmp, "../assets/images/" . $img);

    return $this->baseModel->insert($this->table, $fields, $values);
  }

  public function addBlog($request)
  {
    $fields = 'articleTitle, articleCategory, articleDescrip, articleImage';
    $values = "'" . implode("','", array_values($request)) . "'";
    $img = $_FILES['articleImage']['name'];
    $values .= ",'" . $img . "'";
    $img_tmp = $_FILES['articleImage'];
    $img_tmp = $_FILES['articleImage']['tmp_name'];
    move_uploaded_file($img_tmp, "../assets/images/" . $img);

    return $this->baseModel->insert($this->table1, $fields, $values);
  }

  public function getUser($id)
  {
    return $this->baseModel->select($this->table, $id);
  }

  public function getData()
  {
    return $this->baseModel->selectEmail($this->table);
  }

  public function getUsers()
  {
    return $this->baseModel->selectAll($this->table);
  }

  public function getEmail()
  {
    return $this->baseModel->selectEmail($this->table);
  }

  public function getBlogs()
  {
    return $this->baseModel->selectAll($this->table1);
  }

  public function getBlog($id)
  {
    return $this->baseModel->selectBlog($this->table1, $id);
  }
  public function deleteUserById($id)
  {
    return $this->baseModel->delete($this->table, 'id', $id);
  }

  public function deleteBlogById($id)
  {
    return $this->baseModel->delete($this->table1, 'articleId', $id);
  }

  public function updateUser($id)
  {
    $updatedFields = "name = '{$_POST['name']}', surname = '{$_POST['surname']}', email = '{$_POST['email']}'";
    return $this->baseModel->update($this->table, $updatedFields, $id);
  }

  public function updateBlog($id)
  {
    $img = $_FILES['articleImage']['name'];
    // $values .= ",'" . $img . "'";
    $img_tmp = $_FILES['articleImage'];
    $img_tmp = $_FILES['articleImage']['tmp_name'];
    // print_r($img);
    // exit;
    move_uploaded_file($img_tmp, "../assets/images/" . $img);
    $updatedFields = "articleTitle = '{$_POST['articleTitle']}', articleCategory = '{$_POST['articleCategory']}', articleDescrip = '{$_POST['articleDescrip']}', articleImage = '{$img}'";
    // echo $updatedFields;
    // exit;
    return $this->baseModel->updateBlogData($this->table1, $updatedFields, $id);
  }

  public function updateUsers($email)
  {
    $updatedFields = "first_name = '{$_POST['first_name']}', last_name = '{$_POST['last_name']}', email = '{$_POST['email']}', mobile_no = '{$_POST['mobile_no']}', password = '{$_POST['password']}'";
    return $this->baseModel->updateProfile($this->table, $updatedFields, $email);
  }

  public function userLogin($email, $password)
  {
    return $this->authenticationModel->login($this->table, $email, $password);
  }

  public function verifyEmail()
  {
    return $this->baseModel->emailSelect($this->table);
  }
}