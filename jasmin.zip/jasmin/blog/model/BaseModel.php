<?php
session_start();
include_once 'Connection.php';

class BaseModel extends Connection
{

  public $connection;


  public function __construct()
  {
    $this->connection = new Connection();
  }

  public function insert($tablename, $fields, $values)
  {
    $sql = "INSERT INTO {$tablename} ({$fields}) VALUES ({$values})";
    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function select($tableName, $id)
  {
    $sql = "SELECT * FROM {$tableName} WHERE id={$id}";
    $result = mysqli_query($this->connection->db_connection, $sql);
    $data = [];
    // print_r($data);
    // exit;

    while ($row = mysqli_fetch_array($result)) {
      $data[] = $row;
    }
    return $data;
  }

  public function selectAll($tableName)
  {
    $sql = "SELECT * FROM {$tableName}";
    $result = mysqli_query($this->connection->db_connection, $sql);
    $data = [];

    while ($row = mysqli_fetch_assoc($result)) {
      $data[] = $row;
    }
    return $data;
  }

  public function selectBlog($tableName, $id)
  {
    $sql = "SELECT * FROM {$tableName} WHERE articleId={$id}";
    // echo $sql;
    // exit;
    $result = mysqli_query($this->connection->db_connection, $sql);
    $data = [];

    while ($row = mysqli_fetch_assoc($result)) {
      $data[] = $row;
    }
    return $data;
  }

  public function selectEmail($tableName)
  {
    $sql = "SELECT * FROM {$tableName} WHERE email='{$_SESSION['email']}'";
    $result = mysqli_query($this->connection->db_connection, $sql);
    $data = [];

    while ($row = mysqli_fetch_assoc($result)) {
      $data[] = $row;
    }
    return $data;
  }

  public function emailSelect($tableName)
  {
    $sql = "SELECT * FROM {$tableName} WHERE email='{$_POST['email']}'";
    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function delete($tableName, $fieldName, $values)
  {
    $sql = "DELETE FROM {$tableName} WHERE {$fieldName}={$values}";
    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function update($tableName, $updatedFields, $id)
  {
    $sql = "UPDATE {$tableName} SET {$updatedFields} WHERE id={$id}";
    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function updateBlogData($tableName, $updatedFields, $id)
  {
    $sql = "UPDATE {$tableName} SET {$updatedFields} WHERE articleId={$id}";
    return mysqli_query($this->connection->db_connection, $sql);
  }
  public function updateProfile($tableName, $updatedFields, $email)
  {
    $sql = "UPDATE {$tableName} SET {$updatedFields} WHERE email='{$email}'";
    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function emailVerify($tableName)
  {
    $sql = "SELECT email FROM {$tableName} WHERE email = '{$_POST['email']}'";
    return mysqli_query($this->connection->db_connection, $sql);
  }
}