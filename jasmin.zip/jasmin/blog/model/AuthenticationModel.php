<?php

include_once 'Connection.php';

class AuthenticationModel extends Connection
{
    public $connection;

    public function __construct()
  {
    $this->connection = new Connection();
  }

  public function login($tableName,$email,$password)
  {
    $sql = "SELECT * FROM {$tableName}  WHERE email = '{$email}' AND password = '{$password}'";  
    // echo $sql;
    // exit;
    return mysqli_query($this->connection->db_connection, $sql);
  }

}

?>