<?php

class RouteController
{

  public function __construct()
  {
    $action = $_SERVER['QUERY_STRING'];

    if (empty($action)) {
      $action = "create";
    }

    switch ($action) {
      case 'create':
        header("location: view/authentication/login.php");
        break;

      default:
        # code...
        break;
    }
  }
}