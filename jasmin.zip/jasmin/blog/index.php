<?php

require_once 'controller/RouteController.php';

$routeController = new RouteController();