<!-- Remove the container if you want to extend the Footer to full width. -->
<div class="my-5">

    <footer class="text-white text-center text-lg-start bg-dark">

    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2022 Copyright JD's BLOG
    </div>
    <!-- Copyright -->
  </footer>
  
</div>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<!-- End of .container -->