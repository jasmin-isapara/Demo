//Request Insert  Data

$(document).ready(function () {


    //view All data
    function showdata() {
        output = ""; 
        $.ajax({
            url: "/php/MVC_AJAX_CRUD/model/retrieve.php",
            method: "GET",
            dataType: "json",
            success: function (data) {
                //console.log(data);

                if (data) {
                    x = data;
                }
                else {
                    x = "";
                }
                for (i = 0; i < x.length; i++) {
                    output += "<tr><td>" + x[i].id + "</td><td>" + x[i].name + "</td><td>" + x[i].email + "</td><td>" + x[i].password + "</td><td> <button class='btn btn-warning btn-sm btn-edit' data-sid="+ x[i].id +">Edit</button>  <button class='btn btn-danger  btn-sm btn-del' data-sid="+ x[i].id +">Delete</button></td></tr>"
                    //console.log(x[i]);
                }
                $("#tbody").html(output);
            },  
        });
    }
    showdata(); 

    //Insert  Data

    $("#btnadd").click(function (e) {
        e.preventDefault(); //this method is not relode the page.

        console.log("save button clicked");
        
        let stid = $("#stuid").val();
        let nm = $("#nameid").val();
        let em = $("#emailid").val();
        let pw = $("#pwdid").val();

        // console.log(nm);
        // console.log(em);
        // console.log(pw);

        mydata = { id: stid, name: nm, email: em, password: pw }; // JS OBJECT
        //console.log(mydata);

        $.ajax({
            url: "/php/MVC_AJAX_CRUD/model/insert.php",
            method: "POST",
            data: JSON.stringify(mydata),// convert into string and send in server..
            success: function (data) {
                // console.log(data);
                msg = "<div class='alert alert-dark mt-3'>" + data + "</div>";
                $("#msg").html(msg);
                $("#myform")[0].reset();
                showdata();
            },
        });
    });  
    //Delete A Data.
    $("tbody").on("click",".btn-del", function(){
        console.log("Delete Button Clicked");
        let id = $(this).attr("data-sid");
    //    console.log(id);
    mydata = {sid: id};
    mythis = this;
    $.ajax({
        url:"/php/MVC_AJAX_CRUD/model/delete.php",
        method:"POST",
        data: JSON.stringify(mydata),
        success:function(data){
            //console.log(data);  
            if(data == 1)
            {
                msg = "<div class='alert alert-dark mt-3'>Student Deleted Successfully.</div>";
                
                $(mythis).closest("tr").fadeOut(); 
            }
            else{

                msg = "<div class='alert alert-dark mt-3'>Unable Deleted Student.</div>";
            }
            $("#msg").html(msg);
        },
       
    });
    });

    // Editing A Data...
    $("tbody").on("click",".btn-edit", function(){
        $('#btnupdate').show();
        $('#btnadd').hide();
       
        console.log("Edit Button Clicked");
        let id = $(this).attr("data-sid");
        //console.log(id);
        mydata = {sid: id};
       
        $.ajax({
            url:"/php/MVC_AJAX_CRUD/model/edit.php",
            method: "POST",
            dataType: "json", //convert string into js object
            data: JSON.stringify(mydata),
            success:function(data){
               // console.log(data);
               $("#stuid").val(data.id);
               $("#nameid").val(data.name);
               $("#emailid").val(data.email);
               $("#pwdid").val(data.password);
            },
        });
    });


    $("#btnupdate").click(function (e) {
        e.preventDefault(); //this method is not relode the page.

        console.log("save button clicked");
        
       let stid = $("#stuid").val();
        let nm = $("#nameid").val();
        let em = $("#emailid").val();
        let pw = $("#pwdid").val();

        // console.log(nm);
        // console.log(em);
        // console.log(pw);

        mydata = {student_id:stid,name: nm, email: em, password: pw }; // JS OBJECT
        console.log(mydata);

        $.ajax({
            url: "/php/MVC_AJAX_CRUD/model/update.php",
            method: "POST",
            data: JSON.stringify(mydata),// convert into string and send in server..
            success: function (data) {
                // console.log(data);
                msg = "<div class='alert alert-dark mt-3'>" + data + "</div>";
                $("#msg").html(msg);
                $("#myform")[0].reset();
                showdata();
            },
        });
    });  

});
