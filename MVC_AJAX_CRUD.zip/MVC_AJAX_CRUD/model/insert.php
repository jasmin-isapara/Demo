<?php
    include('connection.php');

    $data = stripslashes(file_get_contents("php://input")); // read a raw data from a request body..  //stripslash is clean up html form data
    $mydata = json_decode($data, true);
    //$id = $mydata['id'];
    $name = $mydata['name'];
    $email = $mydata['email'];
    $password = $mydata['password'];

    // INSERT  DATA..
    

    $sql = "INSERT INTO student (name, email, password) VALUES ('$name', '$email', '$password')"; 
    $res = mysqli_query($conn,$sql);
        if($res == TRUE)
            {
                echo "Student Data Saved Successfully.";
            }
            else
            {
                
                echo "Unable To Save Data.";
               
            }
?>