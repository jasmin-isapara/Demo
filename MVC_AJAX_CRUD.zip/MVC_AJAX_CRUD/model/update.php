<?php
    include('connection.php');

    $data = stripslashes(file_get_contents("php://input")); // read a raw data from a request body..  //stripslash is clean up html form data
    $mydata = json_decode($data, true);
    //$id = $mydata['id'];
    $name = $mydata['name'];
    $email = $mydata['email'];
    $password = $mydata['password'];
    $id = $mydata['student_id'];
    
    
   
           $sql = "UPDATE `student` SET name = '$name',`email` = '$email' WHERE `student`.`id` = $id";
           $res = mysqli_query($conn,$sql); 
            if($conn->query($sql) == TRUE)
            {
                echo "Data updated Successfully.";
            }
            else
            {
                echo "Data Is Not Updated.";
            }
