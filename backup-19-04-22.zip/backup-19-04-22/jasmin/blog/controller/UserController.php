<?php
session_start();
include_once '../model/UserModel.php';
include_once '../model/AuthenticationModel.php';

class UserController
{
  public $UserModel;

  public function __construct()
  {
    $this->UserModel = new UserModel();
  }

  public function create()
  {
    $requestData = $_POST;
    $fileData=$_FILES;
    
    // move_uploaded_file($files_temp, '../img/' . $files_name);

    $result = $this->UserModel->create($requestData,$fileData);

    if ($result) {
      header("Location: ../view/authentication/login.php");
      die;
    }
  }

  public function getUserById()
  {
    header("Location: ../View/User/edit.php?update&id={$_GET['id']}");
    die;
  }

  public function deleteUser()
  {
    $result = $this->UserModel->deleteUserById($_GET['id']);

    if ($result) {
      header("Location:../View/User/create.php");
      die;
    }
  }

  public function updateUser()
  {
    $result = $this->UserModel->updateUser($_GET['id']);
    if ($result) {
      header("Location:../View/User/create.php");
      die;
    }
  }

  public function userLogin()
  {
    $result = $this->UserModel->userLogin($_POST['email'], $_POST['password']);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);
    // echo $count;
    // exit;
    if ($_POST['email'] == 'admin@gmail.com' && $_POST['password'] == 'admin') {

      header("location: ../admin/index.php");
    } elseif ($count != 0) {
      $_SESSION['email'] = $_POST['email'];
      echo $_SESSION['email'];
      // exit;  
      header("Location:../view/home.php");
    } else {
      header("Location:../view/error.php");
    }
  }
  // public function logOut(){

}

//   function session() {  
//     if (isset($_SESSION['email'])) {  
//         return $_SESSION['email'];  
//     }  
// }  

$userController = new UserController();

$action = $_SERVER['QUERY_STRING'];

if (!empty(strpos($action, '&'))) {
  $action = substr($action, 0, strpos($action, '&'));
}

switch ($action) {
  case 'create':
    $userController->create();
    break;

  case 'delete':
    $userController->deleteUser();
    break;

  case 'edit':
    $userController->getUserById();
    break;

  case 'update':
    $userController->updateUser();
    break;

  case 'login':
    $userController->userLogin();
    break;

    // case 'logout':
    //   $userController->logOut();
    //   break;

  default:
    # code...
    break;
}
