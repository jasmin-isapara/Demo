<!-- Remove the container if you want to extend the Footer to full width. -->
<div class="my-5">

    <footer class="text-white text-center text-lg-start bg-dark">

    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2022 Copyright JD's BLOG
    </div>
    <!-- Copyright -->
  </footer>
  
</div>
<!-- End of .container -->