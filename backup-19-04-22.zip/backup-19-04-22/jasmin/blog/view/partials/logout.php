<?php
// include '../../controller/UserController.php';

// $userController = new UserController();

// $userController->logOut();
// echo "test";
// exit;
session_unset();
session_destroy();
header("Location:/jasmin/blog/view/authentication/login.php");
