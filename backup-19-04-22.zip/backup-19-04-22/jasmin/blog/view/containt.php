<div class="container">



<h1 class="my-5">Welcom To JD's Blog</h1>


<!-- <h5>If you Dont have an account Than click on Register button</h5> -->
<!-- <br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br> -->
<div class="span8">

<div class="row">

<div class="span7">
<h2>React Native</h2>
<!-- <p>Article Description.</p> -->
<img src="../assets/images/react.png" width="300px" height="500px" class="img-thumbnail"></img><br><br>
<p><a class="btn btn-info" href="#">Read Blog »</a></p>
</div>
</div>

</div>
</div>

</div>