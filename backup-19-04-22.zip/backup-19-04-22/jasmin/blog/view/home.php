<?php
session_start();
include('../view/partials/header.php');
include('../view/partials/navbar.php');
include('containt.php');


include('../view/partials/footer.php');

?>