<?php

include "BaseModel.php";
include 'AuthenticationModel.php';

class UserModel extends BaseModel
{
  public $baseModel;
  public $authenticationModel;
  public $table = "users";
  // public $table2 = "admin";

  public function __construct()
  {
    $this->baseModel = new BaseModel();
    $this->authenticationModel = new AuthenticationModel();
    // return $this->authenticationModel;
  }

  public function create($request)
  {
    $fields = 'first_name, last_name, email, mobile_no, password, image';
    $values = "'" . implode("','", array_values($request)) . "'";

    $target_dir = "/jasmin/blog/assets/images/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    // echo $_SERVER['DOCUMENT_ROOT'];
    // exit;
    $allowed= array('image/pjpeg',
    'image/jpeg', 'image/jpeg',
    'image/JPG', 'image/X-PNG',
    'image/PNG', 'image/png',
    'image/x-png');
    print_r($allowed);
    exit;
    //echo $target_dir;
    if(isset($_POST['submit']))
    {
    
    if(isset($_FILES['image']))
    {
    
    if(in_array($_FILES['image']['type'],$allowed))
    {
    if(move_uploaded_file($_FILES['image']['tmp_name'] , "/jasmin/blog/assets/images/{$_FILES['image']['name']
    }"))
    {
    
    echo "The File has been uploaded";
    }
    else
    {
    echo "Please upload a proper type.";
    }
    
    }
    
    }
    
    if($_FILES['image']['error']>0)
    {
    
    switch($_FILES['image']['error']){
    
    case 1:
    print 'the files exceeds max upload size setting in php.ini';
    break;
    case 2:
    print 'Exceeds MAX_FILE_SIZE in html form';
    break;
    case 3:
    print'The file was only partially uploaded';
    break;
    case 4:
    print 'The file was not uploaded';
    break;
    case 6:
    print 'No temp_file was available';
    break;
    case 7:
    print 'Unable to write to disk';
    break;
    case 8:
    print 'The file upload was stopped';
    default:
    print 'A system error has occured';
    break;
    }
    
    }
    if(file_exists($_FILES['image']['tmp_name']&& is_file($_FILES['image']['tmp_name'])))
    {
    unlink
    ($_FILES['image']['tmp_name']);
    }
    
    }
//     $uploadOk = 1;
//     $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
//     // Check if image file is a actual image or fake image
//     if (isset($_POST["submit"])) {
//       $check = getimagesize($_FILES["image"]["tmp_name"]);
//       if ($check !== false) {
//         echo "File is an image - " . $check["mime"] . ".";
//         $uploadOk = 1;
//       } else {
//         $uploadOk = 0;
//       }
//     }

//     // Check if file already exists
// if (file_exists($target_file)) {
//   echo "Sorry, file already exists.";
//   $uploadOk = 0;
// }

// // Check file size
// if ($_FILES["image"]["size"] > 500000) {
//   echo "Sorry, your file is too large.";
//   $uploadOk = 0;
// }

// // Allow certain file formats
// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
// && $imageFileType != "gif" ) {
//   echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
//   $uploadOk = 0;
// }

// // Check if $uploadOk is set to 0 by an error
// if ($uploadOk == 0) {
//   echo "Sorry, your file was not uploaded.";
// // if everything is ok, try to upload file
// } else {
//   if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
//     echo "The file ". htmlspecialchars( basename( $_FILES["image"]["name"])). " has been uploaded.";
//   } else {
//     echo "Sorry, there was an error uploading your file.";
//   }



    //     $target = "assets/images/";
    //     $target = $target . basename($_FILES['image']['name']);
    //     if (move_uploaded_file($_FILES['image']['name'], $target)) {
    //       //Tells you if its all ok 
    //       echo "The file " . basename($_FILES['image']['name']) . " has been uploaded, and your information has been added to the directory";
    //     } else {
    //       //Gives an error if its not 
    //       echo "Sorry, there was a problem uploading your file.";
    //     }
    // // echo "<pre>";
    //     echo $values;
    //     // echo"</pre>";
    // exit;


    return $this->baseModel->insert($this->table, $fields, $values);
  }

  public function getUser($id)
  {
    return $this->baseModel->select($this->table, $id);
  }

  public function getUsers()
  {
    return $this->baseModel->selectAll($this->table);
  }

  public function deleteUserById($id)
  {
    return $this->baseModel->delete($this->table, 'id', $id);
  }

  public function updateUser($id)
  {
    $updatedFields = "name = '{$_POST['name']}', surname = '{$_POST['surname']}', email = '{$_POST['email']}'";
    return $this->baseModel->update($this->table, $updatedFields, $id);
  }

  public function userLogin($email, $password)
  {
    return $this->authenticationModel->login($this->table, $email, $password);
  }

  // $file = $_FILES['img'];
  //   $files_name = $_FILES['img']['name'];
  //   // $files_size = $_FILES['img']['size'];
  //    $files_temp = $_FILES['img']['tmp_name'];
  //     move_uploaded_file($files_temp,'../img/'.$files_name);

  // public function adminLogin($email, $password)
  // {
  //   return $this->authenticationModel->adlogin($this->table2, $email, $password);
  // }
}
