<?php
// session_start();
include_once 'Connection.php';
// include '../Controller/UserController.php';

class BaseModel extends Connection
{

  public $connection;

  
  public function __construct()
  {
    $this->connection = new Connection();
  
  }

  public function insert($tablename, $fields, $values)
  {
    $sql = "INSERT INTO {$tablename} ({$fields}) VALUES ({$values})";
    echo $sql;
    exit;
    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function select($tableName, $id)
  {
    $sql = "SELECT * FROM {$tableName} WHERE id={$id}";
    $result = mysqli_query($this->connection->db_connection, $sql);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
      $data = $row;
    }
    return $data;
  }

  public function selectAll($tableName)
  {
    // $_SESSION['email'] = $_POST['email'];
    $sql = "SELECT * FROM {$tableName} WHERE email='{$_SESSION['email']}'";
    // echo $sql;
    // exit;
    
    $result = mysqli_query($this->connection->db_connection, $sql);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
      $data[] = $row;
    }
    return $data;
  }

  public function delete($tableName, $fieldName, $values)
  {
    $sql = "DELETE FROM {$tableName} WHERE {$fieldName}={$values}";

    return mysqli_query($this->connection->db_connection, $sql);
  }

  public function update($tableName, $updatedFields, $id)
  {
    $sql = "UPDATE {$tableName} SET {$updatedFields} WHERE id={$id}";
    return mysqli_query($this->connection->db_connection, $sql);
  }

  // public function login($tableName,$email,$password)
  // {
  //   $sql = "SELECT * FROM {$tableName}  WHERE email = '{$email}' AND password = '{$password}'";  
     
  //   return mysqli_query($this->connection->db_connection, $sql);
  // }
}